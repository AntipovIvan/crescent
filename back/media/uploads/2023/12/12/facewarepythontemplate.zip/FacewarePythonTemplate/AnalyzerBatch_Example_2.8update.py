#----------------------------------------------------------------------------------------
# Name:        AnalyzerBatch Example Script
# Author:      Jay Grenier
#
# Created:     2014
# Copyright:   (c) Faceware Technologies, Inc. 2014
#
# Usage:
# 	This module contains contains two classes:
#
#		- AnalyzerBatchConfig - This class handles your configuration for your
#		  pipeline, such as video location, output location, etc.
#
#		- AnalyzerBatchCommands - A Python wrapper for the functionality contained
#		  in the AnalyzerBatch command-line tool.
#
#	Note: Using this script requires a full data set* for an Actor.
#	
#	Step 1: Configure the options in the AnalyzerBatchConfig class.
#	Step 2: Run this module.
#
#	* See full batch documentation for instructions on creating a data set for an actor.
#
#	Updates:
#		- 6/3/2015 - Added manual Job directory creation after 2.8 change in Analyzer to not auto-create it
#
#----------------------------------------------------------------------------------------


# Do not remove the lines below #
import os
import glob
import subprocess
# Do not remove the lines above #

class AnalyzerBatchConfig(object):

	# Class Info:
	# This class covers the basic configuration for running the AnalyzerBatch Commands.
	# You must fill out all of these options or the script will likely not run.

	def __init__(self):

		# Debug - Keep this to true until you've setup all your data paths below.  It will print the commands instead of running them.
		self.debug = True
		if self.debug: 
			print "# -------------------------------- #"
			print "# [Faceware] Debug Mode is Active. #"
			print "# -------------------------------- #"

		# Project Info
		self.AnalyzerBatchPath = "C:\Program Files\Faceware\Analyzer\AnalyzerBatch.exe" # This is the path to AnalyzerBatch.exe, usually found in C:/Program Files/Faceware/Analyzer
		self.Username = "YOUR_USERNAME_HERE" # Valid Faceware Subscription Username
		self.Password = "YOUR_PASSWORD_HERE" # Valid Faceware Subscription Password

		# Analyzer - Pipeline Info
		self.VideoDirectory = "C:/PATH_TO_VIDEOS" # This is the directory path containing your videos.
		self.ActorOutputDirectory = "C:/PATH_FOR_OUTPUT" # This is the path where your output data will be placed.
		self.NeutralFrame = "C:/PATH_TO_NEUTRALFRAME.fwlf" # This is the path to your Neutral Frame file (.fwlf).
		self.ExportLandmarkPositions = True # True or False - Do you want to Export Landmark Positions?
		self.ExportResultsImageSeq = True # True or False - Do you want to export your tracking results on an additional image sequence?

		# Analyzer - Tracking Models
		self.TrackingModels = "C:/PATH_TO_TRACKINGMODELS" # This is the directory path containing your Tracking Models

		# Analyzer - Tracking Options
		self.VideoType = "h" # This is the type of video you are using.  Valid options: "h" -> headcam color, "hbw" -> headcam b&w, or "s" -> static cam
		self.RotateImage = 0 # This is how many degrees you want to rotate your source video when creating a new Job.  Valid options: 0, 90, 180, 270
		self.BurnInFrames = True # True or False - Do you want to burn the frame numbers into each image of the sequence?

		# Analyzer - Advanced
		self.AnalysisDefinition = None # This is the path to the Analysis Definition file you want to use for your job.  Leave 'None' for default.


class AnalyzerBatchCommands(object):

	# Class Info:
	# This class is a Python wrapper for the AnalyzerBatch command-line tools.
	# It draws data from the AnalyzerBatchConfig class in order to run.	

	def __init__(self, AnalyzerBatchConfig):
		self.AnalyzerBatchConfig = AnalyzerBatchConfig # You must initialize this class with an AnalyzerBatchConfig object.
		

	# *********************************************************************************************************#
	# *** NEWJOB - Creates a New Tracking Job in Faceware Analyzer ********************************************#
	# *********************************************************************************************************#
	def newJob(self, VideoFile):
		
		# Check if video exists
		if not self.AnalyzerBatchConfig.debug:
			if not os.path.isfile(VideoFile):
				print "[Faceware] Analyzer NewJob: Video file was not found."
				return

			# Check if FWT already exists
			fwtFile = os.path.join(self.AnalyzerBatchConfig.ActorOutputDirectory, os.path.splitext(os.path.split(VideoFile)[1])[0]+".fwt")
			if os.path.isfile(fwtFile):
				print "[Faceware] Analyzer NewJob: "+fwtFile+" already exists, you can't overwrite an FWT file so we have to skip this video."
				return

		# Path to FwtFile
		jobDir = os.path.join(self.AnalyzerBatchConfig.ActorOutputDirectory, os.path.splitext(os.path.basename(VideoFile))[0])
		FwtFile = os.path.join(jobDir, os.path.split(VideoFile)[1].replace(os.path.splitext(VideoFile)[1], ".fwt"))

		# Create Job Directory if it does not exist
		if not os.path.isdir(jobDir):
			os.mkdir(jobDir)

		# Define all options as blank unless we're given the input
		ir, fb, ad, at, nf = "", "", "", "", ""

		# Construct Image Rotate Option
		if self.AnalyzerBatchConfig.RotateImage != 0:
			ir = "-imageRotate " + str(self.AnalyzerBatchConfig.RotateImage)

		# Construct Frame Burn-in Option
		if self.AnalyzerBatchConfig.BurnInFrames:
			fb = "-frameBurnin"

		# Construct Analysis Definition Option
		if self.AnalyzerBatchConfig.AnalysisDefinition != None:
			ad = "-analysisDefinition \"" + self.AnalyzerBatchConfig.AnalysisDefinition + "\""

		# Construct Neutral Frame Option
		if self.AnalyzerBatchConfig.NeutralFrame != None:
			nf = "-neutralframe \"" + self.AnalyzerBatchConfig.NeutralFrame + "\""

		# Form the Command
		Command = "AnalyzerBatch NewJob \"" +VideoFile+ "\" \"" +FwtFile+ "\" "  +ir+ " " +fb+ " " +ad+ " " +at+ " " +nf

		# Run the Command or, if Debug, print the Command so we can check it looks okay
		if self.AnalyzerBatchConfig.debug:
			print Command
		else:
			os.chdir(os.path.split(self.AnalyzerBatchConfig.AnalyzerBatchPath)[0])
			try:
				process = subprocess.Popen(Command, shell=False, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
				Stdout = []
				while True:
					Line = process.stdout.readline()
					Stdout.append(Line)
					print Line,
					if Line == '' and process.poll() != None:
						break
				print ''.join(Stdout)
				process.communicate()
			except Exception as e:
				print e


		print "[Faceware] AnalyzerBatch NewJob - Finished on "+FwtFile
		return FwtFile


	# *********************************************************************************************************#
	# *** TRACK - Tracks a Job in Faceware AnalyzerBatch ******************************************************#
	# *********************************************************************************************************#
	def track(self, FwtFile):

		# File Checks
		if not self.AnalyzerBatchConfig.debug:
			if not os.path.isfile(FwtFile):
				print "[Faceware] Analyzer Track: FWT Job file was not found."

			if self.AnalyzerBatchConfig.NeutralFrame != None:
				if not os.path.isfile(self.AnalyzerBatchConfig.NeutralFrame):
					print "[Faceware] Analyzer Track: Neutral Frame file was not found."

		if self.AnalyzerBatchConfig.TrackingModels != None:
			models = glob.glob(self.AnalyzerBatchConfig.TrackingModels+"\*.mat")
			for model in models:
				if not os.path.isfile(model):
					print "[Faceware] Analyzer Track: Model file not found, " + model


		# Define all options as blank unless we're given the input
		vt, nf, sm = "", "", ""
		tm = []

		# Construct AutoTrack/VideoType Option
		if self.AnalyzerBatchConfig.VideoType != None:
			at = "-autotrack " + self.AnalyzerBatchConfig.VideoType

		# Construct Neutral Frame Option
		if self.AnalyzerBatchConfig.NeutralFrame != None:
			nf = "-neutralframe \"" + self.AnalyzerBatchConfig.NeutralFrame + "\""

		# Construct Frame Burn-in Option (Currently setup to always use smoothing.)
		sm = "-smoothing"

		# Construct Tracking Model Options
		if len(self.AnalyzerBatchConfig.TrackingModels) > 0:
			for model in models:
				tm.append(" -model \"" + model + "\"")

		# Form the Command
		Command = "AnalyzerBatch Track \"" +FwtFile+ "\" " +at+ " "  +nf+ " " +sm
		for model in tm:
			Command += model

		# Run or Debug Command
		if self.AnalyzerBatchConfig.debug:
			print Command
		else:
			os.chdir(os.path.split(self.AnalyzerBatchConfig.AnalyzerBatchPath)[0])
			try:
				process = subprocess.Popen(Command, shell=False, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
				Stdout = []
				while True:
					Line = process.stdout.readline()
					Stdout.append(Line)
					print Line,
					if Line == '' and process.poll() != None:
						break
				print ''.join(Stdout)
				process.communicate()
				return process.returncode
			except Exception as e:
				print e

		print "AnalyzerBatch Track - Finished on "+FwtFile


	# *********************************************************************************************************#
	# *** EXPORT LANDMARK POSITIONS - Exports 2D positions of each Landmark point. ****************************#
	# *********************************************************************************************************#
	def exportLandmarkPositions(self, FwtFile):

		# Make Path to XML File
		xmlFile = os.path.join(os.path.dirname(FwtFile),os.path.splitext(os.path.basename(FwtFile))[0]+"_FEATUREFILE.xml")

		# File Checks
		if not self.AnalyzerBatchConfig.debug:
			if not os.path.isfile(FwtFile):
				print "[Faceware] Analyzer ExportLandmarkPositions: FWT Job file was not found. Skipping."
				return
			if os.path.isfile(xmlFile):
				print "[Faceware] Analyzer ExportLandmarkPositions: XML Feature File already exist. Skipping."
				return


		# Form the Command
		Command = "AnalyzerBatch ExportLandmarkPositions \"" +FwtFile+ "\" \"" +xmlFile+ "\""

		# Run or Debug Command
		if self.AnalyzerBatchConfig.debug == True:
			print Command
		else:
			os.chdir(os.path.split(self.AnalyzerBatchConfig.AnalyzerBatchPath)[0])
			try:
				process = subprocess.Popen(Command, shell=False, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
				Stdout = []
				while True:
					Line = process.stdout.readline()
					Stdout.append(Line)
					print Line,
					if Line == '' and process.poll() != None:
						break
				print ''.join(Stdout)
				process.communicate()
				return process.returncode
			except Exception as e:
				print e

		print "[Faceware] AnalyzerBatch ExportLandmarkPositions - Finished on "+FwtFile

	# *********************************************************************************************************#
	# *** PARAMETERIZE - Exports tracking data and creates FWR file for Retargeter. ***************************#
	# *********************************************************************************************************#
	def parameterize(self, FwtFile):

		# File Checks
		if not self.AnalyzerBatchConfig.debug:
			if not os.path.isfile(FwtFile):
				print "[Faceware] Analyzer Parameterize: FWT Job file was not found."
				return

			if self.AnalyzerBatchConfig.NeutralFrame != None:
				if not os.path.isfile(self.AnalyzerBatchConfig.NeutralFrame):
					print "[Faceware] Analyzer Parameterize: Neutral Frame file was not found."
					return

		# Define all options as blank unless we're given the input
		nf, url, res = "", "", ""

		# Construct Neutral Frame Option
		if self.AnalyzerBatchConfig.NeutralFrame != None:
			nf = "-actormodel \"" + self.AnalyzerBatchConfig.NeutralFrame + "\""

		# Construct Results Option
		if self.AnalyzerBatchConfig.ExportResultsImageSeq:
			url = "-includetrackingresults"

		# Form the Command
		Command = "AnalyzerBatch Parameterize \"" +FwtFile+ "\" \"" +self.AnalyzerBatchConfig.Username+ "\" \"" +self.AnalyzerBatchConfig.Password+ "\" " +nf+ " " +url+ " " +res

		# Run or Debug Command
		if self.AnalyzerBatchConfig.debug == True:
			print Command
		else:
			os.chdir(os.path.split(self.AnalyzerBatchConfig.AnalyzerBatchPath)[0])
			try:
				process = subprocess.Popen(Command, shell=False, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
				Stdout = []
				while True:
					Line = process.stdout.readline()
					Stdout.append(Line)
					print Line,
					if Line == '' and process.poll() != None:
						break
				print ''.join(Stdout)
				process.communicate()
				return process.returncode
			except Exception as e:
				print e

		print "[Faceware] AnalyzerBatch Parameterize - Finished on "+FwtFile


# *********************************************************************************************************#
# *** Below this line is where we create the Class objects and run the actual processing. *****************#
# *********************************************************************************************************#

# Step 1: Create the AnalyzerBatchConfig Object
Config = AnalyzerBatchConfig()

# Step 2: Create the AnalyzerBatchCommands Object and pass in Config
Cmds = AnalyzerBatchCommands(Config)

# Step 3: Get a list of .mov files in your Video Directory
videos = glob.glob(Config.VideoDirectory+"\*.mov") # This example is specific to .mov files.  Change the extension here or loop through extensions to use others.

# Step 4: Do some basic reporting and checks
print "[Faceware] Found "+str(len(videos))+" video(s) in your Video Directory." # How many videos is it about to process?
if len(videos) < 1:
	print "[Faceware] No videos to process; the script will stop now." # If there are no videos to process, exit the script.
	exit()

# Loop through your videos and run commands
for video in videos:

	# Create a new Job (returns the path to the fwt file it creates)
	fwt = Cmds.newJob(video)	

	# Track the Job
	Cmds.track(fwt)

	# Export 2D Landmark Positions
	Cmds.exportLandmarkPositions(fwt)
	
	# Parameterize and create .fwr file for Retargeter
	Cmds.parameterize(fwt)





