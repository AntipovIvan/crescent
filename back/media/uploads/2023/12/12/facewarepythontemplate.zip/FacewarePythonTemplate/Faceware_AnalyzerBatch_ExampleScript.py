#-------------------------------------------------------------------------------
# Name:         Faceware Analyzer Batch Script Example
#
# Author:       Jay Grenier, Faceware Technologies, Inc.
#
# Created:      February 22, 2013
# Last Updated: December 16. 2013
#
# Copyright:    (c) Faceware Technologies, Inc. 2013
#-------------------------------------------------------------------------------

# Notes:
# AnalyzerBatch itself is a command line executable.  In this example I'm using
# Python to quickly grab files, error check, and do all of the heavy lifting.
# After this I feed the data I need into the AnalyzerBatch executable in Python.
#
# This example script demonstrates how to use the two functions included with
# AnalyzerBatch, "NewJob" and "Parameterize". This example shows how you can put
# a number of videos into a folder and batch them through until they're ready
# for animation.

# Instructions:
# There are several functions laid out below.  The functions that contains your
# options are "ftiAnalyzerBatch_NewJobBatch" (for creating new 'Jobs') and
# "ftiAnalyzerBatch_ParameterizeBatch" for Parameterizing finished 'Jobs'.
#
# At the bottom of this script, use the instructions and uncomment the command
# you'd like to run.



# Import Python Modules
import sys, os, glob, subprocess

#-###################################################
#- 'New Job' Batch Setup
#-###################################################
def ftiAnalyzerBatch_NewJobBatch():

    # Info: Fill in the required variables below to match your project info.

    ###################################################
    # 'New Job' Required Variables

    analyzerBatchDir = "C:/Program Files/Faceware/Analyzer" # LOCATION OF ANALYZERBATCH.EXE

    videoDir = "C:/Path/To/Your/Video/Directory/" # SOURCE VIDEO DIRECTORY

    outputDir = videoDir # JOB FILES DIRECTORY (By default matches the location of the source videos.  Change this if you'd like to.)

    videoExt = "mov" # FILE EXTENSION OF YOUR VIDEOS (avi, mov, mp4, etc.)

    autotrack = True # AUTOTRACK THIS JOB? (True or False)

    tracker = "h" # TYPE OF CAMERA TRACKER ('h' for Headcams, 's' for Static Cameras)

    neutralFrame = "\"C:/Path/To/NeutralFrame.fwlf\"" # PATH TO NEUTRAL FRAME (Optional, used if Autotracking)

    ###################################################

    # Get list of video files in the provided directory
    videoFiles = glob.glob(os.path.join(videoDir,"*."+videoExt))

    ##############################
    ##### Run some checks... #####
    ##############################

    # Does the Video Directory Exist?
    if os.path.isdir(videoDir) == False:
        sys.exit("The video directory you provided does not appear to exist.")

    # Are there Video Files in this Directory?
    if len(videoFiles) == 0:
        sys.exit("No files with the " + videoExt + " extension were found in the directory you provided.")

    ##############################
    ##### Passed all checks! #####
    ##############################

    # Loop through Video Files and Create Jobs for Each
    for video in videoFiles:

        # Run New Job Command - (This command is defined below in a different function.)
        ftiAnalyzerBatch_NewJob(analyzerBatchDir, video, video.replace("."+videoExt, ".fwt"), autotrack, tracker, neutralFrame)

    # Finish Up
    print ("Faceware Analyzer: Jobs were created successfully.")



#-###################################################
#- 'Parameterize' Batch Setup
#-###################################################
def ftiAnalyzerBatch_ParameterizeBatch():

    # Info: Fill in the required variables below to match your project info.

    ###################################################
    # 'Parameterize' Required Variables

    analyzerBatchDir = "C:/Program Files/Faceware/Analyzer"

    fwtDir = "C:/Path/To/FWT/Files/" # FWT DIRECTORY

    username = "YOUR_USERNAME" # Faceware Account Username

    password = "YOUR_PASSWORD" # Faceware Account Password

    ###################################################

    # 'Parameterize' Optional Variables
    actorModel = "C:/Path/To/NeutralFrame.fwlf"
    webUrl = "-url \"https://secure.facewaretech.com/1.0/\"" # Web Service URL
    ranges = "-ranges valid"

    # Create Counters
    fwtProcessed = 0
    fwtFailed = 0

    # Get list of FWT files in the provided directory
    fwtFiles = glob.glob(os.path.join(fwtDir,"*.fwt"))

    ##############################
    ##### Run some checks... #####
    ##############################

    # Does FWT Directory Exist?
    if os.path.isdir(fwtDir) == False:
        sys.exit("The directory you provided for your FWT files does not exist.")

    # Are FWT IMPD Files in this Directory?
    if len(fwtFiles) == 0:
        sys.exit("No FWT files found in the directory you provided.")

    ##############################
    ##### Passed all checks! #####
    ##############################

    # Loop through IMPD Files
    for fwt in fwtFiles:

        # Run New Job Command
        if(ftiAnalyzerBatch_Parameterize(analyzerBatchDir, fwt, username, password, webUrl, ranges, actorModel)):
            fwtProcessed += 1
        else:
            fwtFailed += 1

    # Finish Up
    if fwtProcessed > 0:
        print ("Faceware Analyzer: " + str(fwtProcessed) + " FWT(s) were Parameterized successfully.")
    if fwtFailed > 0:
        print ("Faceware Analyzer: " + str(fwtFailed) + " FWT(s) were not Parameterized.")



#-###################################################
#- Actual 'New Job' Command
#-###################################################
def ftiAnalyzerBatch_NewJob(analyzerBatchDir, videoPath, fwtPath, autotrack, tracker, neutralFrame):

    # Debug
    debug = False # Turns debugging on or off.  Set this to 'True' to print the batch commands instead of running them.

    # Autotrack Setup
    if(autotrack):
        doAutoTrack = "-autotrack " + tracker + " " + "-neutralframe " + neutralFrame
    else:
        doAutoTrack = ""

    # Create New Job Command
    newjobCmd = ("AnalyzerBatch NewJob \"" + videoPath + "\" \"" + fwtPath + "\" " + doAutoTrack) #!# OPTIONAL VARIABLES NOT USED - LOOK FOR THIS IN AN UPDATE. #!#

    # Run Command
    if debug == True:
        print (newjobCmd)
    else:
        os.chdir(analyzerBatchDir)
        subprocess.call(newjobCmd)

    return True


#-###################################################
#- Actual 'Parameterize' Command
#-###################################################
def ftiAnalyzerBatch_Parameterize(analyzerBatchDir, fwtFile, username, password, webUrl, ranges, actorModel):

    # Debug
    debug = False # Turns debugging on or off. Set this to 'True' to print the batch commands instead of running them.

    # Create Parameterize Command
    parameterizeCmd = ("AnalyzerBatch Parameterize \"" + fwtFile + "\" \"" + username  + "\" \"" + password + "\" " + webUrl + " " + actorModel + " " + ranges)

    # Run Command
    if debug == True:
        print (parameterizeCmd)
    else:
        os.chdir(analyzerBatchDir)
        subprocess.call(parameterizeCmd, shell=False)

    return True


#-###################################################
#- Complete Batch Job Setup
#-###################################################
def ftiAnalyzerBatch():

    # Setup new Jobs
    ftiAnalyzerBatch_NewJobBatch()

    # Parameterize your Jobs
    ftiAnalyzerBatch_ParameterizeBatch()




ftiAnalyzerBatch()

















