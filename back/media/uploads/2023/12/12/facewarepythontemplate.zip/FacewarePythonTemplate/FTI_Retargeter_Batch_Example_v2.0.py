#---------------------------------------------------------------------------------
# Name:        Retargeter Batch Example Script
# Author:      Jay Grenier (And Friends)
#
# Created:     2014
# Copyright:   (c) Faceware Technologies, Inc. 2015
#
# Usage:
#     This module contains contains 7 classes:
#
#        - RetargeterBatchConfig - This class handles your configuration for your
#          pipeline, such as .FWR location, output location, etc.
#
#        - RetargeterBatchPipelineMaya/Mobu/Max - These classes contain the 'program' for
#          loading a performance and running the appropriate commands for each FWR file
#          in a directory you've specified in the config class. 
#
#        - RetargeterBatchCommandsMaya/Mobu/Max - A Python wrapper for the functionality contained
#          in Faceware Retargeter.
#
#    Note: Using this script requires a full data set for an Actor.
#    
#    Step 1: Configure the options in the RetargeterBatchConfig class.
#    Step 2: Run this module from within your 3D application (where applicable).
#
#---------------------------------------------------------------------------------

# Change this line to True if you are using Batch with Motionbuilder.
motionBuilder = False

# Do not remove the lines below #

import glob
import os
import subprocess
import sys
import time
import telnetlib
import socket
import imp
import shutil
from _winreg import *
import xml.etree.ElementTree as ET
if motionBuilder == True:
    import pyfbsdk

HOST = "localhost"
PORT = 50000
DEVICENAME = "Faceware Retargeter"  
tn = telnetlib.Telnet()

# Do not remove the lines above #

# Retargeter Configuration
class RetargeterBatchConfig(object):

    # Class Info:
    # This class covers the basic configuration for running the Retargeter Batch Commands.
    # The configuration is agnostic to your 3D application - all options are required regardless of which app you're using.
    # You must fill out all of these options or the script will likely not run.

    def __init__(self):

        # 3D App
        self.SupportedApplications = ["Maya", "Max", "MotionBuilder"] # This is the list of applications supported by Retargeter (Non-Editable)
        self.Application = 2 # Choose the index of the application you're going to use. (e.g. 0 = Maya)
        
        # Data
        self.FwrInputDirectory = "D:/test/jobs" # This is the path where your .FWR files are located.
        self.FwrOutputDirectory = "D:/test/output" # "C:/PATH_TO_OUTPUT_DIRECTORY" # This is the path where your output data will be placed.

        # Scenes and Character Data
        self.FacialRigSceneFile = "D:/test/Facial_Rig.fbx" # "C:/PATH_TO_RIG/MayaFacialRig.mb" # This is the path to your scene file containing your character.
        self.CharacterSetupFile = "D:/test/Character_Setup.xml" #"C:/PATH_TO_XML/CharacterSetupFile.xml" # This is the path your Character Setup file for this character.
        self.SharedPoseDatabase = "D:/test/Shared_Pose_Library.fwsp"#"C:/PATH_TO_SBD/SharedPoses.fwsp" # This is the path to your Shared Pose database file for this character.

        # Scene Setup Options
        self.ImportVideo = False # True or False - Do you want to import the video image sequence of the source video into your scene?
        self.ImportAudio = False # True or False - Do you want to import the audio wav file from your source video into your scene?
        self.SetPlaybackRange = False # True or False - Do you want to set the scenes timeline/playback range to match your source video?
        self.SetFPS = True # True or False - Do you want to set the scene's framerate (FPS) to match your source video?

        # AnimationOptions
        self.GlobalSceneFrameOffset = 0 # Number of frames to offset the animation - this is usually '0'.
        self.AutoSolve = False # Do you want to AutoSolve?  Set to False if using a complete Shared Pose database.
        self.Pruning = 0 # Pruning Value (%)
        self.Smoothing = 0 # Smoothing Value (%)
        self.PruneSpacing = 0 # Prune Spacing Value (Leave this at '0' unless you're an advanced user.)
        self.MasterControl = None # Master Control Value (Leave this at 'None' unless you're an advanced user.)
        self.NumberOfMouthAutoPoses = 10 # Number of Mouth Autoposes to Get 
        self.NumberOfEyeAutoPoses = 6 # Number of Eye Autoposes to Get
        self.NumberOfBrowAutoPoses = 4 # Number of Brow Autoposes to Get
        self.GetAutoPoses = True

# *********************************************************************************************************#
# *** Below this line is where we create the Classes that contain the scripts to run batch.  **************#
# *********************************************************************************************************#

class RetargeterBatchPipelineMaya(object):

    # Class Info:
    # This class handles the actual processing of data.
    # It draws data from the RetargeterBatchConfig class in order to run.
    #
    # You can review and customize this class to fit your needs.
    
    global mel

    def __init__(self, RetargeterBatchConfig):
        self.RetargeterBatchConfig = RetargeterBatchConfig # You must initialize this class with an RetargeterBatchConfig object.

    def run(self):
        
        import maya.cmds as mc
        # Make Sure Input Directory Exists
        if not os.path.isdir(self.RetargeterBatchConfig.FwrInputDirectory):
            print "[Faceware] Retargeter FWR Input Directory does not exist. Stopping!"
            return

        # Make Sure Output Directory Exists
        if not os.path.isdir(self.RetargeterBatchConfig.FwrOutputDirectory):
            print "[Faceware] Retargeter FWR Output Directory does not exist. Stopping!"
            return

        # Make Sure Character Setup File Exists
        if not os.path.isfile(self.RetargeterBatchConfig.CharacterSetupFile):
            print "[Faceware] Character Setup File does not exist. Stopping!"
            return

        # Make Sure Facial Rig Scene File Exists
        if not os.path.isfile(self.RetargeterBatchConfig.FacialRigSceneFile):
            print "[Faceware] Facial Rig Scene File does not exist. Stopping!"
            return

        # Make Sure Shared Pose Database File Exists
        if self.RetargeterBatchConfig.SharedPoseDatabase != None:
            if not os.path.isfile(self.RetargeterBatchConfig.SharedPoseDatabase):
                print "[Faceware] Facial Rig Scene File does not exist. Stopping!"
                return

        # Get List of Retargeting Files from Input Directory
        fwrs = glob.glob(self.RetargeterBatchConfig.FwrInputDirectory+"\*.fwr")

        # Make sure it found at least (1) .FWR File
        print "[Faceware] Found "+str(len(fwrs))+" Retargeting file(s) in your FWR Input Directory." # How many FWRs is it about to process?
        if len(fwrs) < 1:
            print "[Faceware] No Retargeter files to process; the script will stop now." # If there are no videos to process, exit the script.
            return

        # Instantiate Faceware Retargeter Batch Commands
        ftiCmds = RetargeterBatchCommandsMaya(self.RetargeterBatchConfig)

        # Load Retargeter Plugin
        pluginLoaded = False
        ldPlgIns= mc.pluginInfo( q=True, listPlugins=True)
        if ldPlgIns == None:
            try:
                print "[Faceware] Load plugin!"
                mc.loadPlugin("ImRetargetMaya")
                pluginLoaded = True
            except:
                pluginLoaded = False
        else:    
            if "ImRetargetMaya" not in mc.pluginInfo( q=True, listPlugins=True ):
                try:
                    print "[Faceware] Load plugin!"
                    mc.loadPlugin("ImRetargetMaya")
                    pluginLoaded = True
                    
                except:
                    pluginLoaded = False
            else:
                pluginLoaded = True
        if not pluginLoaded:
            print "[Faceware] Can't load ImRetargetMaya.mll plugin. Stopping!"
            return
                
        # Loop through Retargeting Files and Run
        for fwr in fwrs:

            # Fix Path to Forward Slashes for Maya Because It Hates Backslashes For Some Reason
            fwrFix = fwr.replace("\\", "/")

            # Force Open Scene File
            mc.file(self.RetargeterBatchConfig.FacialRigSceneFile, open=True, force=True)
            
            # Open Performance  
            print "Open Performance" 
            ftiCmds.ftiOpenPerformance(fwrFix, self.RetargeterBatchConfig.CharacterSetupFile, self.RetargeterBatchConfig.SetFPS, self.RetargeterBatchConfig.SetPlaybackRange, self.RetargeterBatchConfig.ImportVideo, self.RetargeterBatchConfig.ImportAudio, self.RetargeterBatchConfig.AutoSolve)
            
            # Open Shared Pose Database
            print "Open Shared Pose Database" 
            if(self.RetargeterBatchConfig.SharedPoseDatabase != None):
                ftiCmds.ftiLoadSharedPoseDatabase(self.RetargeterBatchConfig.SharedPoseDatabase)

            # Get Face Groups
            faceGroups = self.ftiGetFaceGroups(self.RetargeterBatchConfig.CharacterSetupFile)    
            print faceGroups

            # Get Frame Ranges, Set Range Options, Get Auto-Poses, and Retarget each Rig Group
            for group in faceGroups:

                # Get Frame Ranges
                groupXmlFile = os.path.join(os.path.split(fwr)[0], os.path.splitext(fwr)[0])+"\\"+group+".xml"
                frameRanges = self.ftiGetFrameRanges(groupXmlFile)

                # Loop Through Frame Ranges (There is almost always just one frame range ("All Frames"), but just in case...)
                for frameRange in frameRanges:    
                    
                    # Edit Frame Range Values (Pruning, Smoothing, etc.)
                    print "Editing Frame Range"
                    ftiCmds.ftiEditFrameRange(group, frameRange, frameRange, self.RetargeterBatchConfig.Pruning, self.RetargeterBatchConfig.PruneSpacing, self.RetargeterBatchConfig.Smoothing, str(self.RetargeterBatchConfig.MasterControl), "", self.RetargeterBatchConfig.AutoSolve)    
                
                for frameRange in frameRanges: 

                    # Get Auto-Poses
                    if self.RetargeterBatchConfig.GetAutoPoses == True:
                        print "Getting Autoposes"
                        groupParams = self.ftiGetFaceGroupParams(self.RetargeterBatchConfig.CharacterSetupFile)
                        groupCheck = groupParams.index(group)

                    if groupParams[groupCheck + 1] == "Mouth_Params":
                        ftiCmds.ftiGetAutoPoses(group, frameRange, self.RetargeterBatchConfig.NumberOfMouthAutoPoses)
                    elif groupParams[groupCheck + 1] == "Brows_Params":
                        ftiCmds.ftiGetAutoPoses(group, frameRange, self.RetargeterBatchConfig.NumberOfBrowAutoPoses)
                    elif groupParams[groupCheck + 1] == "Eyes_Params":
                        ftiCmds.ftiGetAutoPoses(group, frameRange, self.RetargeterBatchConfig.NumberOfEyeAutoPoses)

                # Retarget
                if self.RetargeterBatchConfig.GetAutoPoses == False and self.RetargeterBatchConfig.AutoSolve == False:
                    continue
                else:
                    print "Retargeting"
                    ftiCmds.ftiRetarget(group, frameRange)

            # Save Maya File
            print "Trying to save."
            currentFilename = os.path.split(fwr)[1]
            newFilename = os.path.join(self.RetargeterBatchConfig.FwrOutputDirectory, os.path.splitext(currentFilename)[0]+"_BATCHRETARGETED"+os.path.splitext(mc.file(query=True, sceneName=True))[1])
            mc.file(rename=newFilename)
            mc.file(save=True)
            print "Save complete"

            # Playblast File (Note, hard-coded to work with avi extensions.  Change here to alter this.)
            # playblastFile = newFilename.replace(".mb", ".avi")
            # mc.playblast(f=playblastFile)

            # Create New File to Release Assets
            mc.file(newFile=True, force=True)

            # Move FWR and Data Folder to Job Folder
            print "Moving Files..."
            dataDir = os.path.splitext(fwr)[0]
            shutil.move(fwr, self.RetargeterBatchConfig.FwrOutputDirectory)
            shutil.move(dataDir, self.RetargeterBatchConfig.FwrOutputDirectory)
            print "Files moved"

        # Defer until idle then quit Maya
        print "Quitting"
        mc.evalDeferred("mc.quit(force=True)")

    # ##############################################
    # Below this line (but in this class) you'll find a few useful utility functions that we're using above.
    # ##############################################

    def ftiGetFaceGroups(self, charSetupFile):
        faceGroups = []
        xml = ET.parse(charSetupFile)
        groupNodes = xml.findall(".//Component/Name")
        for node in groupNodes:
            faceGroups.append(node.text)
        return faceGroups

    def ftiGetFaceGroupParams(self, charSetupFile):
        faceParams = []
        xml = ET.parse(charSetupFile)
        root = xml.getroot()
        for node in root:
            if node.tag == 'Component':
                faceParams.append(node[0].text)
                faceParams.append(node[1].text)
        return faceParams

    def ftiGetFrameRanges(self, groupXmlFile):
        frameRanges = []
        xml = ET.parse(groupXmlFile)
        rangeNamesNodes = xml.findall(".//RetargetRanges/RetargetRange/RangeName")
        for node in rangeNamesNodes:
            frameRanges.append(node.text)
        return frameRanges

class RetargeterBatchPipelineMobu(object):

    # Class Info:
    # This class handles the actual processing of data.
    # It draws data from the RetargeterBatchConfig class in order to run.
    #
    # You can review and customize this class to fit your needs.

    def __init__(self, RetargeterBatchConfig):
        self.RetargeterBatchConfig = RetargeterBatchConfig # You must initialize this class with an RetargeterBatchConfig object.

        
    def run(self):
        
        # Make Sure Input Directory Exists
        if not os.path.isdir(self.RetargeterBatchConfig.FwrInputDirectory):
            print "[Faceware] Retargeter FWR Input Directory does not exist. Stopping!"
            return

        # Make Sure Output Directory Exists
        if not os.path.isdir(self.RetargeterBatchConfig.FwrOutputDirectory):
            print "[Faceware] Retargeter FWR Output Directory does not exist. Stopping!"
            return

        # Make Sure Character Setup File Exists
        if not os.path.isfile(self.RetargeterBatchConfig.CharacterSetupFile):
            print "[Faceware] Character Setup File does not exist. Stopping!"
            return

        # Make Sure Facial Rig Scene File Exists
        if not os.path.isfile(self.RetargeterBatchConfig.FacialRigSceneFile):
            print "[Faceware] Facial Rig Scene File does not exist. Stopping!"
            return

        # Make Sure Shared Pose Database File Exists
        if self.RetargeterBatchConfig.SharedPoseDatabase != None:
            if not os.path.isfile(self.RetargeterBatchConfig.SharedPoseDatabase):
                print "[Faceware] Facial Rig Scene File does not exist. Stopping!"
                return

        # Get List of Retargeting Files from Input Directory
        fwrs = glob.glob(self.RetargeterBatchConfig.FwrInputDirectory+"\*.fwr")

        # Make sure it found at least (1) .FWR File
        print "[Faceware] Found "+str(len(fwrs))+" Retargeting file(s) in your FWR Input Directory." # How many FWRs is it about to process?
        if len(fwrs) < 1:
            print "[Faceware] No Retargeter files to process; the script will stop now." # If there are no videos to process, exit the script.
            return

        #Instantiate Motionbuilder File I/O functions.
        app = pyfbsdk.FBApplication()

        # Loop through Retargeting Files and Run
        for fwr in fwrs:

            # Fix Path to Forward Slashes for Mobu 
            fwrFix = fwr.replace("\\", "/")

            # Force Open Scene File
            app.FileOpen(self.RetargeterBatchConfig.FacialRigSceneFile, False)

            # Instatiate Motionbuilder Commands - This class handles opening and connecting the device. 
            ftiCmds = RetargeterBatchCommandsMotionBuilder()

            # Open Performance    
            print "Open Performance" 
            ftiCmds.ftiOpenPerformance(fwrFix, self.RetargeterBatchConfig.CharacterSetupFile, self.RetargeterBatchConfig.SetFPS, self.RetargeterBatchConfig.SetPlaybackRange, self.RetargeterBatchConfig.ImportVideo, self.RetargeterBatchConfig.ImportAudio, self.RetargeterBatchConfig.AutoSolve)

            # Open Shared Pose Database
            print "Open Shared Pose Database" 
            if(self.RetargeterBatchConfig.SharedPoseDatabase != None):
                ftiCmds.ftiLoadSharedPoseDatabase(self.RetargeterBatchConfig.SharedPoseDatabase)

            # Get Face Groups
            faceGroups = self.ftiGetFaceGroups(self.RetargeterBatchConfig.CharacterSetupFile)            

            # Get Frame Ranges, Set Range Options, Get Auto-Poses, and Retarget each Rig Group
            for group in faceGroups:

                # Get Frame Ranges
                groupXmlFile = os.path.join(os.path.split(fwr)[0], os.path.splitext(fwr)[0])+"\\"+group+".xml"
                frameRanges = self.ftiGetFrameRanges(groupXmlFile)

                # Loop Through Frame Ranges (There is almost always just one frame range ("All Frames"), but just in case...)
                for frameRange in frameRanges:    
                    
                    # Edit Frame Range Values (Pruning, Smoothing, etc.)
                    print "Editing Frame Range"
                    ftiCmds.ftiEditFrameRange(group, frameRange, frameRange, self.RetargeterBatchConfig.Pruning, self.RetargeterBatchConfig.PruneSpacing, self.RetargeterBatchConfig.Smoothing, str(self.RetargeterBatchConfig.MasterControl), "", self.RetargeterBatchConfig.AutoSolve, "1")    
                
                for frameRange in frameRanges: 

                    # Get Auto-Poses
                    if self.RetargeterBatchConfig.GetAutoPoses == True:
                        print "Getting Autoposes"
                        groupParams = self.ftiGetFaceGroupParams(self.RetargeterBatchConfig.CharacterSetupFile)
                        groupCheck = groupParams.index(group)

                    if groupParams[groupCheck + 1] == "Mouth_Params":
                        ftiCmds.ftiGetAutoPoses(group, frameRange, self.RetargeterBatchConfig.NumberOfMouthAutoPoses)
                    elif groupParams[groupCheck + 1] == "Brows_Params":
                        ftiCmds.ftiGetAutoPoses(group, frameRange, self.RetargeterBatchConfig.NumberOfBrowAutoPoses)
                    elif groupParams[groupCheck + 1] == "Eyes_Params":
                        ftiCmds.ftiGetAutoPoses(group, frameRange, self.RetargeterBatchConfig.NumberOfEyeAutoPoses)

                # Retarget
                if self.RetargeterBatchConfig.GetAutoPoses == False and self.RetargeterBatchConfig.AutoSolve == False:
                    continue
                else:
                    print "Retargeting"
                    ftiCmds.ftiRetarget(group, frameRange)

            # Save Motionbuilder File
            currentFilename = os.path.basename(fwr)
            newFilename = os.path.join(self.RetargeterBatchConfig.FwrOutputDirectory, os.path.splitext(currentFilename)[0]+"_BATCHRETARGETED.fbx")
            app.FileSave(newFilename)

            # Kill Retargeter GUI. Must kill GUI before opening next Scene. 
            os.system("taskkill /im FacewareRetargeter_GUI.exe")

            # Create New File to Release Assets
            app.FileNew()

            # Move FWR and Data Folder to Job Folder
            dataDir = os.path.splitext(fwr)[0]
            fwrDest = os.path.join(self.RetargeterBatchConfig.FwrOutputDirectory, os.path.basename(fwr))
            os.rename(fwr, fwrDest)
            shutil.move(dataDir, self.RetargeterBatchConfig.FwrOutputDirectory)

        
    # ##############################################
    # Below this line (but in this class) you'll find a few useful utility functions that we're using above.
    # ##############################################

    def ftiGetFaceGroups(self, charSetupFile):
        faceGroups = []
        xml = ET.parse(charSetupFile)
        groupNodes = xml.findall(".//Component/Name")
        for node in groupNodes:
            faceGroups.append(node.text)
        return faceGroups

    def ftiGetFaceGroupParams(self, charSetupFile):
        faceParams = []
        xml = ET.parse(charSetupFile)
        root = xml.getroot()
        for node in root:
            if node.tag == 'Component':
                faceParams.append(node[0].text)
                faceParams.append(node[1].text)
        return faceParams

    def ftiGetFrameRanges(self, groupXmlFile):
        frameRanges = []
        xml = ET.parse(groupXmlFile)
        rangeNamesNodes = xml.findall(".//RetargetRanges/RetargetRange/RangeName")
        for node in rangeNamesNodes:
            frameRanges.append(node.text)
        return frameRanges

class RetargeterBatchPipelineMAX(object):

    # Class Info:
    # This class handles the actual processing of data.
    # It draws data from the RetargeterBatchConfig class in order to run.
    #
    # You can review and customize this class to fit your needs.
   

    def __init__(self, RetargeterBatchConfig):
        self.RetargeterBatchConfig = RetargeterBatchConfig # You must initialize this class with an RetargeterBatchConfig object.

        import MaxPlus
            
    def run(self):

        # Make Sure Input Directory Exists
        if not os.path.isdir(self.RetargeterBatchConfig.FwrInputDirectory):
            print "[Faceware] Retargeter FWR Input Directory does not exist. Stopping!"
            return

        # Make Sure Output Directory Exists
        if not os.path.isdir(self.RetargeterBatchConfig.FwrOutputDirectory):
            print "[Faceware] Retargeter FWR Output Directory does not exist. Stopping!"
            return

        # Make Sure Character Setup File Exists
        if not os.path.isfile(self.RetargeterBatchConfig.CharacterSetupFile):
            print "[Faceware] Character Setup File does not exist. Stopping!"
            return

        # Make Sure Facial Rig Scene File Exists
        if not os.path.isfile(self.RetargeterBatchConfig.FacialRigSceneFile):
            print "[Faceware] Facial Rig Scene File does not exist. Stopping!"
            return

        # Make Sure Shared Pose Database File Exists
        if self.RetargeterBatchConfig.SharedPoseDatabase != None:
            if not os.path.isfile(self.RetargeterBatchConfig.SharedPoseDatabase):
                print "[Faceware] Facial Rig Scene File does not exist. Stopping!"
                return

        # Get List of Retargeting Files from Input Directory
        fwrs = glob.glob(self.RetargeterBatchConfig.FwrInputDirectory+"\*.fwr")

        # Make sure it found at least (1) .FWR File
        print "[Faceware] Found "+str(len(fwrs))+" Retargeting file(s) in your FWR Input Directory." # How many FWRs is it about to process?
        if len(fwrs) < 1:
            print "[Faceware] No Retargeter files to process; the script will stop now." # If there are no videos to process, exit the script.
            return

        # Instantiate Faceware Retargeter Batch Commands
        ftiCmds = RetargeterBatchCommandsMax(self.RetargeterBatchConfig)

        # Load Retargeter Plugin
        
        pluginLoaded = MaxPlus.Core.EvalMAXScript("UtilityPanel.OpenUtility Faceware")
        if pluginLoaded.Get() == True:
            print "Plugin Loaded"
        else: 
            print "Plugin Failed to Load"
                
        # Loop through Retargeting Files and Run
        for fwr in fwrs:

            # Fix Path to Forward Slashes for Maya Because It Hates Backslashes For Some Reason
            fwrFix = fwr.replace("\\", "/")

            # Force Open Scene File
            sceneLoaded = MaxPlus.Core.EvalMAXScript('loadMaxFile ' + '"' + self.RetargeterBatchConfig.FacialRigSceneFile + '"' + ' useFileUnits:True quiet:True')
            if sceneLoaded.Get() == True:
                print "Scene Loaded"
            else: 
                print "Scene Failed to Load"

            # Open Performance  
            print "Open Performance" 
            ftiCmds.ftiOpenPerformance(fwrFix, self.RetargeterBatchConfig.CharacterSetupFile, self.RetargeterBatchConfig.SetFPS, self.RetargeterBatchConfig.SetPlaybackRange, self.RetargeterBatchConfig.ImportVideo, self.RetargeterBatchConfig.ImportAudio, self.RetargeterBatchConfig.AutoSolve)
            
            # Open Shared Pose Database
            print "Open Shared Pose Database" 
            if(self.RetargeterBatchConfig.SharedPoseDatabase != None):
                ftiCmds.ftiLoadSharedPoseDatabase(self.RetargeterBatchConfig.SharedPoseDatabase)

            # Get Face Groups
            faceGroups = self.ftiGetFaceGroups(self.RetargeterBatchConfig.CharacterSetupFile)    
            print faceGroups

            # Get Frame Ranges, Set Range Options, Get Auto-Poses, and Retarget each Rig Group
            for group in faceGroups:

                # Get Frame Ranges
                groupXmlFile = os.path.join(os.path.split(fwr)[0], os.path.splitext(fwr)[0])+"\\"+group+".xml"
                frameRanges = self.ftiGetFrameRanges(groupXmlFile)

                # Loop Through Frame Ranges (There is almost always just one frame range ("All Frames"), but just in case...)
                for frameRange in frameRanges:    
                    
                    # Edit Frame Range Values (Pruning, Smoothing, etc.)
                    print "Editing Frame Range"
                    ftiCmds.ftiEditFrameRange(group, frameRange, frameRange, self.RetargeterBatchConfig.Pruning, self.RetargeterBatchConfig.PruneSpacing, self.RetargeterBatchConfig.Smoothing, str(self.RetargeterBatchConfig.MasterControl), "", self.RetargeterBatchConfig.AutoSolve)    
                
                for frameRange in frameRanges: 

                    # Get Auto-Poses
                    if self.RetargeterBatchConfig.GetAutoPoses == True:
                        print "Getting Autoposes"
                        groupParams = self.ftiGetFaceGroupParams(self.RetargeterBatchConfig.CharacterSetupFile)
                        groupCheck = groupParams.index(group)

                    if groupParams[groupCheck + 1] == "Mouth_Params":
                        ftiCmds.ftiGetAutoPoses(group, frameRange, self.RetargeterBatchConfig.NumberOfMouthAutoPoses)
                    elif groupParams[groupCheck + 1] == "Brows_Params":
                        ftiCmds.ftiGetAutoPoses(group, frameRange, self.RetargeterBatchConfig.NumberOfBrowAutoPoses)
                    elif groupParams[groupCheck + 1] == "Eyes_Params":
                        ftiCmds.ftiGetAutoPoses(group, frameRange, self.RetargeterBatchConfig.NumberOfEyeAutoPoses)

                # Retarget
                if self.RetargeterBatchConfig.GetAutoPoses == False and self.RetargeterBatchConfig.AutoSolve == False:
                    continue
                else:
                    print "Retargeting"
                    ftiCmds.ftiRetarget(group, frameRange)

            # Save Max File
            print "Saving File"
            currentFilename = os.path.split(fwr)[1]
            newFilename = os.path.join(self.RetargeterBatchConfig.FwrOutputDirectory, os.path.splitext(currentFilename)[0]+"_BATCHRETARGETED")
            fileSaved = MaxPlus.Core.EvalMAXScript('saveMaxFile ' + '"' + newFilename + '"' + ' useNewFile:True quiet:True')
            if fileSaved.Get() == True:
                print "Save complete"
            else: 
                print "Failed to Save"

            # Create New File to Release Assets
            MaxPlus.Core.EvalMAXScript('resetMAXFile #noPrompt')

            # Move FWR and Data Folder to Job Folder
            print "Moving Files..."
            dataDir = os.path.splitext(fwr)[0]
            shutil.move(fwr, self.RetargeterBatchConfig.FwrOutputDirectory)
            shutil.move(dataDir, self.RetargeterBatchConfig.FwrOutputDirectory)
            print "Files moved"

        # Defer until idle then quit Maya
        #print "Quitting!"
        #mc.evalDeferred("mc.quit(force=True)")


    # ##############################################
    # Below this line (but in this class) you'll find a few useful utility functions that we're using above.
    # ##############################################

    def ftiGetFaceGroups(self, charSetupFile):
        faceGroups = []
        xml = ET.parse(charSetupFile)
        groupNodes = xml.findall(".//Component/Name")
        for node in groupNodes:
            faceGroups.append(node.text)
        return faceGroups

    def ftiGetFaceGroupParams(self, charSetupFile):
        faceParams = []
        xml = ET.parse(charSetupFile)
        root = xml.getroot()
        for node in root:
            if node.tag == 'Component':
                faceParams.append(node[0].text)
                faceParams.append(node[1].text)
        return faceParams

    def ftiGetFrameRanges(self, groupXmlFile):
        frameRanges = []
        xml = ET.parse(groupXmlFile)
        rangeNamesNodes = xml.findall(".//RetargetRanges/RetargetRange/RangeName")
        for node in rangeNamesNodes:
            frameRanges.append(node.text)
        return frameRanges

# *********************************************************************************************************#
# *** Below this line is where we create the Classes that contain the commands for each app. **************#
# *********************************************************************************************************#

class RetargeterBatchCommandsMaya(object):

    # Class Info:
    # This class is a Python wrapper for the Retargeter Batch Commands for Maya.
    # It draws data from the RetargeterBatchConfig class in order to run.
    #
    # You should not need to edit this class.

    def __init__(self, RetargeterBatchConfig):
        self.RetargeterBatchConfig = RetargeterBatchConfig # You must initialize this class with an RetargeterBatchConfig object.

        # Import Necessary Maya Modules
        global mel
        import maya.mel as mel
        import maya.cmds as mc

    def ftiAddPose(self, poseGroup, frameNum, description):
        command = "ImAddPose \"" + poseGroup + "\" " + str(frameNum) + " \"" + description + "\""     
        mel.eval(command)


    def ftiAddSharedPose(self, poseGroup, frameNum):
        command = "ImAddSharedPose \"" + poseGroup + "\" " + str(frameNum)
        mel.eval(command)


    def ftiBackup(self, backupName):
        command = "ImBackup \"" + backupName + "\""
        mel.eval(command)


    def ftiCreateFrameRange(self, poseGroup, rangeName, rangeNum):
        command = "ImAddRetargetRange \"" + poseGroup + "\" \"" + rangeName + "\" \"" + rangeNum + "\""
        mel.eval(command)


    def ftiCreateSharedPoseDatabase(self, filepath):
        command = "ImCreateNetworkDatabase \"" + filepath + "\""
        mel.eval(command)


    def ftiCharacterSetup(self):
        mel.eval("ImCharacterSetup")


    def ftiCopyPose(self, poseGroup, frameNum, newFrameNum, newDescription):
        command = "ImCopyPose \"" + poseGroup + "\" " + str(frameNum) + " " + str(newFrameNum) + " \"" + newDescription + "\""
        mel.eval(command)


    def ftiDeleteFrameRange(self, poseGroup, rangeName):
        command = "ImDeleteRetargetingRange \"" + poseGroup + "\" \"" + rangeName + "\""
        mel.eval(command)


    def ftiDeletePose(self, poseGroup, frameNum, deleteKeys):
        command = "ImDeletePose \"" + poseGroup + "\" " + str(frameNum) + " \"" + deleteKeys + "\""
        mel.eval(command)


    def ftiEditFrameRange(self, poseGroup, rangeName, newRangeName, pruning, pruneSpacing, smoothing, masterControl, rangeNum, autoSolve):
        command = "ImEditRetargetingRange \"" + poseGroup + "\" \"" + rangeName + "\" \"" + newRangeName + "\" " + str(pruning) + " " + str(pruneSpacing) + " " + str(smoothing) + " \"" + masterControl + "\" \"" + rangeNum + "\" \"" + str(autoSolve) + "\""
        mel.eval(command)


    def ftiEditPoseDescription(self, poseGroup, frameNum, description):
        command = "ImSetPoseName \"" + poseGroup + "\" " + str(frameNum) + " \"" + description + "\""
        mel.eval(command)


    def ftiGetAutoPoses(self, poseGroup, frameRange, numPoses):
        command = "ImGetAutoPoses " + poseGroup + " \"" + frameRange + "\" " + str(numPoses)
        mel.eval(command)


    def ftiLoadSharedPoseDatabase(self, path):
        command = "ImSetNetworkDatabase \"" + path + "\""
        mel.eval(command)


    def ftiMovePose(self, poseGroup, frameNum, newFrameNum, newDescription):
        command = "ImMovePose \"" + poseGroup + "\" " + str(frameNum) + " " + str(newFrameNum) + " \"" + newDescription + "\""
        mel.eval(command)


    def ftiOpenPerformance(self, fwr, charSetupFile, setFPS, setRange, importAudio, importVideo, autosolve):
        command = "ftiOpenPerformance \"" + fwr + "\" \"" + charSetupFile + "\""
        if setFPS == True:
            command += " -fr 1"
        if setRange == True:
            command += " -pr 1"
        if importAudio == True:
            command += " -a 1"
        if importVideo == True:
            command += " -v 1"
        if autosolve == True:
            command += " -as 1"
        print command
        mel.eval(command)


    def ftiRestoreBackup(self, backupName):
        command = "ImRestore \"" + backupName + "\""
        mel.eval(command)


    def ftiRetarget(self, poseGroup, frameRange):
        command = "ftiRetarget " + poseGroup + " \"" + frameRange + "\""
        mel.eval(command)


    def ftiRetargeter(self):
        mel.eval("Retargeter")


    def ftiToggleUsePose(self, poseGroup, frameRange, frameNum, use):
        command = "ImUpdatePoseSelected " + poseGroup + " \"" + frameRange + "\" " + str(frameNum) + " " + use
        mel.eval(command)

class RetargeterBatchCommandsMotionBuilder(object):
  
  def __init__( self ):
      
    # the GUID below is retrieved from the Application ID in InstallJammer
    aKey = OpenKey( HKEY_LOCAL_MACHINE, r"Software\Microsoft\Windows\CurrentVersion\Uninstall\FacewareRetargeterMobu2015x64", 0, KEY_READ | KEY_WOW64_64KEY )
    standalongexepath, type = QueryValueEx( aKey, "InstallLocation" )
    
    standalongexepath = os.path.join( standalongexepath, 'FacewareRetargeter_GUI.exe' )
    self._runstandalong(standalongexepath)
    self._adddevice()
    self._connect()

  # Run standalong is it hasn't run
  def _runstandalong(self, standalongexepath):
    processliststring = subprocess.Popen(["wmic", "process", "get", "executablepath"], stdout=subprocess.PIPE).stdout.read()
    processlist = [ x.strip().lower().replace("\\", "/") for x in processliststring.split("\n") ]
    if(standalongexepath.lower() not in processlist):
      subprocess.Popen(standalongexepath)

  # Add retarget device if not found
  def _adddevice(self):
    device = self._finddevice(DEVICENAME)
    if not device:
      device = pyfbsdk.FBCreateObject("Browsing/Templates/Devices", DEVICENAME, DEVICENAME)
      device.Online = True
      pyfbsdk.FBSystem().Scene.Devices.append(device)
      print DEVICENAME + " device added."
    else:
      print DEVICENAME + " device found."

  # Find retarget device
  def _finddevice(self, name):
    result = None
    devicelist = pyfbsdk.FBSystem().Scene.Devices
    if devicelist:
      for device in devicelist:
        if device.Name == name:
          result = device
          break
    return result

  # Connect to Mobu retarget GUI
  def _connect(self):
    global tn
    try:
      tn.open(HOST, PORT)
    except socket.error as detail:
      print detail

  # Send the command across the connection
  def _send(self, command, retry = 3):
    global tn
    if not (command.endswith("\n")):
      command = command + "\n"
    sent = False
    while (not sent) and (retry > 0):
      try:
        tn.read_very_eager()
        tn.write(command)
        sent = True
      except AttributeError as detail:
        self._connect()
        retry = retry - 1
        if(retry == 0):
          print detail
    return sent

  # Receive response
  def _receive(self):
    try:
      result = tn.read_until("\n", 1)
      newline = False
      while(len(result) == 0):
        sys.stdout.write('.')
        newline = True
        time.sleep(1)
        result = tn.read_until("\n", 1)
      if newline:
        print ""
      result = result.strip()
      return result
    except Exception as detail:
      print detail
      return "0 " + str(detail)

  # Execute Mobu command in string
  def execute(self, command):
    global tn
    if not (command.endswith("\n")):
      command = command + "\n"
    if(self._send(command)):
      result = self._receive()
      #print result
      if(not bool(int(result[0]))):
        raise Exception(result[2:])
      else:
        return result[2:]

  # ftiAddPose("Brows", 10, "PoseName")
  def ftiAddPose(self, posegroupname, sceneframenumber, posename):
    self.execute("ImAddPose " +
      "\"" + posegroupname + "\" " +
      "\"" + str(sceneframenumber) + "\" " +
      "\"" + posename + "\"")

  # ftiAddRetargetRange("Brows", "Not All", "1-10")
  def ftiAddRetargetRange(self, posegroupname, rangename, range):
    self.execute("ImAddRetargetRange " +
      "\"" + posegroupname + "\" " +
      "\"" + rangename + "\" " +
      "\"" + range + "\"")

  # ftiAddSharedPose("Brows", 0")
  def ftiAddSharedPose(self, posegroupname, sceneframenumber):
    self.execute("ImAddSharedPose " +
      "\"" + posegroupname + "\" " +
      "\"" + str(sceneframenumber))

  # ftiApplySharedPoseToScene("Brows", "Male2_Sports_Instructor_Line002_Andre_IM", 0)
  def ftiApplySharedPoseToScene(self, posegroupname, jobname, framenumber):
    self.execute("ImApplySharedPoseToScene " +
      "\"" + posegroupname + "\" " +
      "\"" + jobname + "\" " +
      "\"" + str(framenumber) + "\"")

  # ftiBackup("FolderName")
  def ftiBackup(self, foldername):
    self.execute("ImBackup " +
      "\"" + foldername + "\"")

  # ftiClearAllKeys("Brows", "All Frames")
  def ftiClearAllKeys(self, posegroupname, rangename):
    self.execute("ImClearAllKeys " +
      "\"" + posegroupname + "\" " +
      "\"" + rangename + "\"")

  # ftiCompareImaToScene("Brows", "Brows_All Frames.ima")
  def ftiCompareImaToScene(self, posegroupname, filename):
    self.execute("ImCompareImaToScene " +
      "\"" + posegroupname + "\" " +
      "\"" + filename + "\"")

  # ftiComparePosesToPoseGroupFile("Brows", "Brows_All Frames.impd")
  def ftiComparePosesToPoseGroupFile(self, posegroupname, filename):
    self.execute("ImComparePosesToPoseGroupFile " +
      "\"" + posegroupname + "\" " +
      "\"" + filename + "\"")

  # ftiComparePosesToScene("Brows")
  def ftiComparePosesToScene(self, posegroupname):
    self.execute("ImComparePosesToScene " +
      "\"" + posegroupname + "\"")

  # ftiCopyPose("Brows", 0, 10, "CopiedPose")
  def ftiCopyPose(self, posegroupname, sceneframenumber, newframenumber, newposename):
    self.execute("ImCopyPose " +
      "\"" + posegroupname + "\" " +
      "\"" + str(sceneframenumber) + "\" " +
      "\"" + str(newframenumber) + "\" " +
      "\"" + newposename + "\"")

  # ftiCreateSharedPoseDatabase("c:/test.db")
  def ftiCreateSharedPoseDatabase(self, databasepath):
    self.execute("ImCreateNetworkDatabase " +
      "\"" + databasepath + "\"")

  # ftiDefaultCurrentFrame("Brows")
  def ftiDefaultCurrentFrame(self, posegroupname):
    self.execute("ImDefaultCurrentFrame " +
      "\"" + posegroupname + "\"")

  # ftiDeletePose("Brows", 10, False)
  def ftiDeletePose(self, posegroupname, sceneframenumber, deleteKeys = False):
    self.execute("ImDeletePose " +
      "\"" + posegroupname + "\" " +
      "\"" + str(sceneframenumber) + "\" " +
      "\"" + str(int(deleteKeys)) + "\"")

  # ftiDeleteRetargetingRange(self, "Eyes", "All Frames")
  def ftiDeleteRetargetingRange(self, posegroupname, rangename):
    self.execute("ImDeleteRetargetingRange " +
      "\"" + posegroupname + "\" " +
      "\"" + rangename + "\"")

  # ftiDeleteSharedPose(self, "Eyes", "C:/test.fwr", "25")
  def ftiDeleteSharedPose(self, posegroupname, jobname, framenumber):
    self.execute("ImDeleteSharedPose " +
      "\"" + posegroupname + "\" " +
      "\"" + jobname + "\" " +
      "\"" + str(framenumber) + "\"")

  # ftiEditFrameRange("Brows", "All Frames", "Not All", 0, 0, 0, "", "1-10", False, 1)
  def ftiEditFrameRange(self, posegroupname, rangename, newrangename, pruning, prunebuffer, smoothing, mastercontrol, rangestr, useautosolve, poseweight):
    self.execute("ImEditRetargetingRange " +
      "\"" + posegroupname + "\" " +
      "\"" + rangename + "\" " +
      "\"" + newrangename + "\" " +
      "\"" + str(pruning) + "\" " +
      "\"" + str(prunebuffer) + "\" " +
      "\"" + str(smoothing) + "\" " +
      "\"" + mastercontrol + "\" " +
      "\"" + rangestr + "\" " +
      "\"" + str(int(useautosolve)) + "\" " +
      "\"" + str(poseweight) + "\"")

  # ftiExportPoseGroupKeys("Brows", "c:/test.txt")
  def ftiExportPoseGroupKeys(self, posegroupname, exportfileName):
    self.execute("ImExportPoseGroupKeys " +
      "\"" + posegroupname + "\" " +
      "\"" + exportfileName + "\"")

  # ftiGetAutoPoses("Brows", "All Frames", 3)
  def ftiGetAutoPoses(self, posegroupname, rangename, numposes):
    self.execute("ImGetAutoPoses " +
      "\"" + posegroupname + "\" " +
      "\"" + rangename + "\" "
      "\"" + str(numposes) + "\"")

  # ftiGetValueOrKeyValue("testing", 0, False)
  def ftiGetValueOrKeyValue(self, controlname, framenumber, iskeyvalue):
    self.execute("ImGetValueOrKeyValue " +
      "\"" + controlname + "\" " +
      "\"" + str(framenumber) + "\" "
      "\"" + str(int(iskeyvalue)) + "\"")

  # ftiOpenPerformance(performanceFile, characterFile)
  def ftiOpenPerformance(self, performanceFile, characterFile, setFrameRate = False, setPlaybackRange = False, importVideo = False, importAudio = False, generateAutoSolve = False):
    cmd = "ftiOpenPerformance \"" + performanceFile + "\" \"" + characterFile + "\" "
    if setFrameRate == True:
      cmd += " SetFrameRate"
    if setPlaybackRange == True:
      cmd += " SetPlaybackRange"
    if importVideo == True:
      cmd += " ImportVideo"
    if importAudio == True:
      cmd += " ImportAudio"
    if generateAutoSolve == True:
      cmd += " GenerateAutoSolve"
    self.execute(cmd)

  # ftiMovePose("Brows", 0, 10, "CopiedPose")
  def ftiMovePose(self, posegroupname, sceneframenumber, newframenumber, newposename):
    self.execute("ImMovePose " +
      "\"" + posegroupname + "\" " +
      "\"" + str(sceneframenumber) + "\" " +
      "\"" + str(newframenumber) + "\" " +
      "\"" + newposename + "\"")

  # ftiReloadRetargetingResults("Brows", "All Frames")
  def ftiReloadRetargetingResults(self, posegroupname, rangename):
    self.execute("ImReloadRetargetingResults " +
      "\"" + posegroupname + "\" " +
      "\"" + rangename + "\"")

  # ftiRestoreBackup("Foldername")
  def ftiRestoreBackup(self, foldername):
    self.execute("ImRestore " +
      "\"" + foldername + "\"")

  # ftiRevertToPoses("Brows", "All Frames")
  def ftiRevertToPoses(self, posegroupname, rangename):
    self.execute("ImRevertToPoses " +
      "\"" + posegroupname + "\" " +
      "\"" + rangename + "\"")

  # ftiRunDiagnostics("c:/log.log", "1-10")
  def ftiRunDiagnostics(self, logfile, rangestr):
    self.execute("ImRunDiagnostics " +
      "\"" + logfile + "\" " +
      "\"" + rangestr + "\"")

  # ftiRetarget("Brows", "All Frames", 0, False)
  def ftiRetarget(self, posegroupname, rangename, selectedtype = 0, generateautosolve = False):
    print str(selectedtype)
    self.execute("ftiRetarget " +
      "\"" + posegroupname + "\" " +
      "\"" + rangename + "\" " +
      ("-UseSelectedControls " if (selectedtype != 0) else "") +
      "\"" + str(selectedtype) + "\" " +
      ("-GenerateAutoSolve " if bool(generateautosolve) else ""))

  # ftiLoadSharedPoseDatabase("d:/Shared_Poses.imdb")
  def ftiLoadSharedPoseDatabase(self, filename):
    self.execute('ftiLoadSharedPoseDatabase "' +  filename + '"')
    
  # ftiSetPlaybackRange()
  def ftiSetPlaybackRange(self):
    self.execute("ImSetPlaybackRange")

  # ftiSetPoseName("Brows", 1, "SetName")
  def ftiSetPoseName(self, posegroupname, sceneframenumber, newposename):
    self.execute("ImSetPoseName " +
      "\"" + posegroupname + "\" " +
      "\"" + str(sceneframenumber) + "\" " +
      "\"" + newposename + "\"")
  
  # ftiSetSceneFrameOffset(1)
  def ftiSetSceneFrameOffset(self, offset):
    self.execute("ImSetSceneFrameOffset " +
      "\"" + str(offset) + "\"")

  # ftiSetServices()
  def ftiSetServices(self):
    self.execute("ImSetServices " +
      "\"" + posegroupname + "\"")

  # ftiUpdatePose("Brows", 0)
  def ftiUpdatePose(self, posegroupname, sceneframenumber):
    self.execute("ImUpdatePose " +
      "\"" + posegroupname + "\" " +
      "\"" + str(sceneframenumber) + "\"")

  # ftiToggleUsePose("Brows", "All Frames", 0, True)
  def ftiToggleUsePose(self, posegroupname, rangename, sceneframenumber, isselected):
    self.execute("ImUpdatePoseSelected " +
      "\"" + posegroupname + "\" " +
      "\"" + rangename + "\" " +
      "\"" + str(sceneframenumber) + "\" " + 
      "\"" + str(int(isselected)) + "\"")

  # ftiUpdateSharedPoses("Brows", "Eyes", "Mouth")
  def ftiUpdateSharedPoses(self, *poses):
    self.execute("ImUpdateSharedPoses " +
      "\"" + "\" \"".join(poses) + "\"")

  # ftiUpdateSharedPoseSelected("Brows", "All Fraames", "Male2_Sports_Instructor_Line002_Andre_IM", 10, 0)
  def ftiUpdateSharedPoseSelected(self, posegroupname, rangename, jobname, framenumber, isselected):
    self.execute("ImUpdateSharedPoseSelected " +
      "\"" + posegroupname + "\" " +
      "\"" + rangename + "\" " +
      "\"" + jobname + "\" " + 
      "\"" + str(framenumber) + "\" " + 
      "\"" + str(int(isselected)) + "\"")

class RetargeterBatchCommandsMax(object):

    # Class Info:
    # This class is a Python wrapper for the Retargeter Batch Commands for Maya.
    # It draws data from the RetargeterBatchConfig class in order to run.
    #
    # You should not need to edit this class.

    def __init__(self, RetargeterBatchConfig):
        self.RetargeterBatchConfig = RetargeterBatchConfig # You must initialize this class with an RetargeterBatchConfig object.

        # Import Necessary Max Modules
        import MaxPlus
        
    def ftiAddPose(self, poseGroup, frameNum, description):
        command = 'ImAddPose "{}" {} "{}"'.format(poseGroup,frameNum,description)   
        MaxPlus.Core.EvalMAXScript(command)


    def ftiAddSharedPose(self, poseGroup, frameNum):
        command = 'ImAddSharedPose "{}" {}'.format(poseGroup,frameNum)
        MaxPlus.Core.EvalMAXScript(command)


    def ftiBackup(self, backupName):
        command = 'ImBackup "{}"'.format(backupName)
        MaxPlus.Core.EvalMAXScript(command)


    def ftiCreateFrameRange(self, poseGroup, rangeName, rangeNum):
        command = 'ImAddRetargetRange "{}" "{}" "{}"'.format(poseGroup,rangeName,rangeNum)
        MaxPlus.Core.EvalMAXScript(command)


    def ftiCreateSharedPoseDatabase(self, filepath):
        command = 'ImCreateNetworkDatabase "{}"'.format(filepath)
        MaxPlus.Core.EvalMAXScript(command)


    def ftiCharacterSetup(self):
        MaxPlus.Core.EvalMAXScript("ImCharacterSetup")


    def ftiCopyPose(self, poseGroup, frameNum, newFrameNum, newDescription):
        command = 'ImCopyPose "{}" {} {} "{}"'.format(poseGroup,frameNum,newFrameNum,newDescription)
        MaxPlus.Core.EvalMAXScript(command)


    def ftiDeleteFrameRange(self, poseGroup, rangeName):
        command = 'ImDeleteRetargetingRange "{}" "{}"'.format(poseGroup,rangeName)
        MaxPlus.Core.EvalMAXScript(command)


    def ftiDeletePose(self, poseGroup, frameNum, deleteKeys):
        command = 'ImDeletePose "{}" {} {}'.format(poseGroup,frameNum,deleteKeys)
        MaxPlus.Core.EvalMAXScript(command)


    def ftiEditFrameRange(self, poseGroup, rangeName, newRangeName, pruning, pruneSpacing, smoothing, masterControl, rangeNum, autoSolve):
        numberOne = '1'
        command = 'ImEditRetargetingRange "{}" "{}" "{}" {} {} {} "{}" "{}" {} 1'.format(str(poseGroup),str(rangeName),str(newRangeName),pruning,pruneSpacing,smoothing,str(masterControl),rangeNum,autoSolve)
        MaxPlus.Core.EvalMAXScript(command)


    def ftiEditPoseDescription(self, poseGroup, frameNum, description):
        command = 'ImSetPoseName "{}" {} "{}"'.format(poseGroup,frameNum,description)
        MaxPlus.Core.EvalMAXScript(command)


    def ftiGetAutoPoses(self, poseGroup, frameRange, numPoses):
        command = 'ImGetAutoPoses  "{}" "{}" {}'.format(poseGroup,frameRange,numPoses)
        MaxPlus.Core.EvalMAXScript(command)


    def ftiLoadSharedPoseDatabase(self, path):
        command = 'ftiLoadSharedPoseDatabase "{}"'.format(path)
        MaxPlus.Core.EvalMAXScript(command)


    def ftiMovePose(self, poseGroup, frameNum, newFrameNum, newDescription):
        command = 'ImMovePose "{}" {} {} "{}"'.format(poseGroup,frameNum,newFrameNum,newDescription)
        MaxPlus.Core.EvalMAXScript(command)


    def ftiOpenPerformance(self, fwr, charSetupFile, setFPS, setRange, importAudio, importVideo, autosolve):
            command = 'ftiOpenPerformance "{}" "{}"'.format(fwr,charSetupFile) 
            if setFPS == True:
                    command += ' "fr"'
            if setRange == True:
                    command += ' "pr"'
            if importAudio == True:
                    command += ' "a"'
            if importVideo == True:
                    command += ' "v"'
            if autosolve == True:
                    command += ' "as"'
            print command
            MaxPlus.Core.EvalMAXScript(command)


    def ftiRestoreBackup(self, backupName):
        command = 'ImRestore "{}"'.format(backupName)
        MaxPlus.Core.EvalMAXScript(command)


    def ftiRetarget(self, poseGroup, frameRange):
        command = 'ftiRetarget "{}" "{}"'.format(poseGroup,frameRange)  #+ poseGroup + " \"" + frameRange + "\""
        MaxPlus.Core.EvalMAXScript(command)


    def ftiRetargeter(self):
        MaxPlus.Core.EvalMAXScript("Retargeter")


    def ftiToggleUsePose(self, poseGroup, frameRange, frameNum, use):
        command = 'ImUpdatePoseSelected "{}" "{}" {} {}'.format(poseGroup,frameRange,frameNum,use)
        MaxPlus.Core.EvalMAXScript(command)

# *********************************************************************************************************#
# *** Below this line is where we create the Class objects and run the actual processing. *****************#
# *********************************************************************************************************#

# Step 1: Create the RetargeterBatchConfig Object
Config = RetargeterBatchConfig()

# Step 2: Based on the application you've selected, create the appropriate class object.
if Config.Application == 0:
    Pipeline = RetargeterBatchPipelineMaya(Config)
elif Config.Application == 1:
    Pipeline = RetargeterBatchPipelineMAX(Config)
elif Config.Application == 2:
    Pipeline = RetargeterBatchPipelineMobu(Config)


# Step 3: Go!
Pipeline.run()





